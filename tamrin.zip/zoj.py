a=int(input("1st number:"))
b=int(input("2nd number:"))
for i in range(a,b):
    if(i%2==0):
        print(i)
